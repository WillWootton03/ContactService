package contactServiceTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.contactService;


class ContactServiceTest {
	
	private String goodValue = "1";
	private String badValue = "11111111111111111111111111111111111";

	
	@Test
	public void test_good_AddContact() 
	{
		contactService service = new contactService();

		service.AddContact(goodValue);
		assertTrue(service.Contacts.containsKey(goodValue));
	}
	
	@Test
	public void test_RemoveContact()
	{
		contactService service = new contactService();

		service.AddContact(goodValue);
		service.RemoveContact(goodValue);
		
		assertFalse(service.Contacts.containsKey(goodValue));

	}
	
	@Test
	public void test_good_UpdateContactFirstName()
	{
		contactService service = new contactService();
		
		service.AddContact(goodValue);
	
		service.UpdateFirstName(goodValue, goodValue);
		assertTrue
		(service.Contacts.get(goodValue).GetFirstName() == goodValue);
	}
	
	@Test
	public void test_good_UpdateContactLastName()
	{
		contactService service = new contactService();
		
		service.AddContact(goodValue);
	
		service.UpdateLastName(goodValue, goodValue);
		assertTrue
		(service.Contacts.get(goodValue).GetLastName() == goodValue);
	}
	
	@Test
	public void test_good_UpdateContactPhone()
	{
		contactService service = new contactService();
		
		service.AddContact(goodValue);
	
		service.UpdatePhone(goodValue, goodValue);
		
		assertTrue
		(service.Contacts.get(goodValue).GetPhone() == goodValue);
	}
	
	@Test
	public void test_good_UpdateContactAddress()
	{
		contactService service = new contactService();
		
		service.AddContact(goodValue);
		service.UpdateAddress(goodValue, goodValue);
		
		assertTrue
		(service.Contacts.get(goodValue).GetAddress() == goodValue);
	}

}
