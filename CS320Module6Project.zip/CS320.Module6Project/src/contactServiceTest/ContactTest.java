package contactServiceTest;



import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.contact;

class ContactTest {

	private String goodValue = "1";
	private String badValue = "11111111111111111111111111111111111";
	
	@Test
	void test__good_UID() 
	{
		contact contact = new contact();
		contact.SetUID(goodValue);
		Assertions.assertTrue(contact.GetUID()== goodValue);
	}
	
	@Test
	void test_good_FirstName()
	{
		contact contact = new contact();
		contact.SetFirstName(goodValue);
		Assertions.assertTrue(contact.GetFirstName()== goodValue);
	}
	
	@Test
	void test_good_LastName()
	{
		contact contact = new contact();
		contact.SetLastName(goodValue);
		Assertions.assertTrue(contact.GetLastName()== goodValue);
	}
	
	@Test
	void test_good_Phone()
	{
		contact contact = new contact();
		contact.SetPhone(goodValue);
		Assertions.assertTrue(contact.GetPhone()== goodValue);
	}

	@Test
	void test_good_Address()
	{
		contact contact = new contact();
		contact.SetAddress(goodValue);
		Assertions.assertTrue(contact.GetAddress()== goodValue);
	}	
}
