package appointmentServiceTest;



import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointmentService.appointment;

class AppointmentTest {

	private String goodValue ="1";
	private String badValue = "111111111111111111111111111111111111111111111111111111111";
	
	@Test
	void test_set_good_UID()
	{
		appointment newAppointment = new appointment();
		newAppointment.SetUID(goodValue);
		Assertions.assertTrue(newAppointment.GetUID()==goodValue);
	}
	
	@Test
	void test_good_Date()
	{
		appointment newAppointment = new appointment();
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 5);	//Sets date to be after current date
		Date goodDate = calendar.getTime();
		
		newAppointment.SetDate(goodDate);
		Assertions.assertTrue(newAppointment.GetDate()==goodDate);
	
	}
	
	@Test
	void test_good_Description()
	{
		appointment newAppointment = new appointment();
		newAppointment.SetDescription(goodValue);
		Assertions.assertTrue(newAppointment.GetDescription() == goodValue);
	}
	
	@Test
	void test_bad_UID()
	{
		appointment newAppointment = new appointment();
		
		newAppointment.SetUID(goodValue);
		
		newAppointment.SetUID(badValue);
		Assertions.assertFalse(newAppointment.GetUID()==badValue);
		newAppointment.SetUID(null);
		Assertions.assertFalse(newAppointment.GetUID()==null);
	}
	@Test
	void test_bad_Date() 
	{
		appointment newAppointment = new appointment();
		Date badDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 5);	//Sets date to be after current date
		Date goodDate = calendar.getTime();
		
		newAppointment.SetDate(goodDate);
		newAppointment.SetDate(badDate);
		Assertions.assertFalse(newAppointment.GetDate()==badDate);
		newAppointment.SetDate(null);
		Assertions.assertFalse(newAppointment.GetDate()==null);
		
	}
	@Test
	void test_bad_Description()
	{
		appointment newAppointment = new appointment();
		
		newAppointment.SetDescription(goodValue);
		newAppointment.SetDescription(badValue);
		Assertions.assertFalse(newAppointment.GetDescription()==badValue);
		newAppointment.SetDescription(null);
		Assertions.assertFalse(newAppointment.GetDescription()==null);
	}
}
