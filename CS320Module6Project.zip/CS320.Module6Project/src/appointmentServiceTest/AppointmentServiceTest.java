package appointmentServiceTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import appointmentService.appointmentService;


class AppointmentServiceTest {

	private String goodValue ="1";
	
	@Test
	void test_AddAppointment()
	{
		appointmentService service = new appointmentService();
		service.AddAppointment(goodValue);
		
		assertTrue(service.Appointments.containsKey(goodValue));
	}
	
	@Test
	void test_DeleteAppointment()
	{
		appointmentService service = new appointmentService();
		service.AddAppointment(goodValue);
		service.DeleteAppointment(goodValue);
		
		assertFalse(service.Appointments.containsKey(goodValue));
	}
	
	
}
