package taskServiceTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.taskService;

class TaskServiceTest 
{
	private String goodValue  = "1";
	private String badValue = "1111111111111111111111111111111111111111111111111111111111";
	
	@Test
	void test_good_AddTask()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		assertTrue(service.Tasks.containsKey(goodValue));
	}
	
	@Test
	void test_RemoveTask()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		service.DeleteTask(goodValue);
		
		assertFalse(service.Tasks.containsKey(goodValue));
	}
	
	@Test
	void test_good_UpdateName()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		service.UpdateName(goodValue, goodValue);
				
		Assertions.assertTrue(service.Tasks.get(goodValue).GetName()==goodValue);
	}
	
	@Test
	void test_good_UpdateDescription()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		service.UpdateDescription(goodValue, goodValue);
				
		Assertions.assertTrue(service.Tasks.get(goodValue).GetDescription()==goodValue);
	}
	@Test
	void test_bad_UpdateName()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		service.UpdateName(goodValue, goodValue);
		service.UpdateName(goodValue, badValue);
		
		Assertions.assertFalse(service.Tasks.get(goodValue).GetName()==badValue);
	}
	@Test
	void test_bad_UpdateDescription()
	{
		taskService service = new taskService();
		
		service.AddTask(goodValue);
		service.UpdateDescription(goodValue, goodValue);
		service.UpdateDescription(goodValue, badValue);
	
		Assertions.assertFalse(service.Tasks.get(goodValue).GetDescription()==badValue);
	}
}
