package taskServiceTest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.task;

class TaskTest 
{
	private String goodValue = "1";
	private String badValue = "111111111111111111111111111111111111111111111111111";

	@Test
	void test_good_UID()
	{
		task task = new task();
		task.SetUID(goodValue);
		Assertions.assertTrue(task.GetUID()== goodValue);
	}
	
	@Test
	void test_good_Name()
	{
		task task = new task();
		task.SetName(goodValue);
		Assertions.assertTrue(task.GetName()== goodValue);
	}
		
	@Test
	void test_good_Description()
	{
		task task = new task();
		task.SetDescription(goodValue);
		Assertions.assertTrue(task.GetDescription()== goodValue);
	}
	@Test
	void test_bad_UID()
	{
		task task = new task();
		task.SetUID(goodValue);
	}
	@Test
	void test_bad_Name()
	{
		task task = new task();
		task.SetName(goodValue);
		task.SetName(badValue);
		Assertions.assertFalse(task.GetName()== badValue);
	}
	@Test
	void test_bad_Description()
	{
		task task = new task();
		task.SetDescription(goodValue);
		task.SetDescription(badValue);
		Assertions.assertFalse(task.GetDescription()== badValue);
	}



}
