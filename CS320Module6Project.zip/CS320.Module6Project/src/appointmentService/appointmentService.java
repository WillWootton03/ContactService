package appointmentService;

import java.util.HashMap;
import java.util.Map;

public class appointmentService {
	public Map<String, appointment> Appointments = new HashMap<>();
	
	public appointment GetAppointment(String UID)
	{
		if(Appointments.containsKey(UID))
			return Appointments.get(UID);
		else
			return null;
	}
	public void AddAppointment(String UID)
	{
		appointment newAppointment = new appointment();
		newAppointment.SetUID(UID);
		Appointments.put(UID, newAppointment);
	}
	public void DeleteAppointment(String UID)
	{
		Appointments.remove(UID);
	}
}
