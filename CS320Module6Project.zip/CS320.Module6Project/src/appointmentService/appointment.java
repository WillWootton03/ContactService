package appointmentService;

import java.util.Date;

public class appointment {

	private String UID = null;
	private Date appointmentDate = new Date();
	private String description = "default";
	
	public String GetUID() { return UID;}
	public Date GetDate() { return appointmentDate;}
	public String GetDescription() { return description;} 
	
	public void SetUID(String UID)
	{
		if(UID != null && UID.length() >= 1 && UID.length() <= 10)
			this.UID = UID;
	}
	public void SetDate(Date appointmentDate)
	{
		if(appointmentDate != null && appointmentDate.after(new Date()))
			this.appointmentDate = appointmentDate;
	}
	public void SetDescription(String description)
	{
		if(description != null && description.length() >= 1 && description.length() <= 50)
			this.description = description;
	}
}
