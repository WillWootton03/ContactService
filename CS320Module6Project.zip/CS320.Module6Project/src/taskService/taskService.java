package taskService;

import java.util.HashMap;
import java.util.Map;

public class taskService {
	
	public Map<String, task> Tasks = new HashMap<>();
	
	
	public task GetTask(String UID)
	{
		if(Tasks.containsKey(UID)){return Tasks.get(UID);}
		return null;
	}
	public void AddTask(String UID)
	{
		task task = new task();
		task.SetUID(UID);
		Tasks.put(UID, task);
	}
	public void DeleteTask(String UID)
	{
		Tasks.remove(UID);
	}
	public void UpdateName(String UID, String name)
	{
		GetTask(UID).SetName(name); 
	}
	public void UpdateDescription(String UID, String description)
	{
		GetTask(UID).SetDescription(description);
	}
}
