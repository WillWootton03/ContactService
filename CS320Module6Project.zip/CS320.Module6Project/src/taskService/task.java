package taskService;

public class task {
	private String UID = null;
	private String name = "default";
	private String description = "default";
	
	public String GetUID() {return UID;}
	public String GetName() {return name;}
	public String GetDescription() {return description;}
	
	public void SetUID(String UID)
	{
		if(UID != null && UID.length() <= 10 && UID.length() >= 1)
			this.UID = UID;
	}
	public void SetName(String name)
	{
		if(name != null && name.length() <= 20 && name.length() >= 1)
			this.name = name;
	}
	public void SetDescription(String description)
	{
		if(description != null && description.length() <= 50 && description.length() >= 1)
			this.description = description;
	}
}
