package contactService;

import java.util.HashMap;

public class contactService {
	
public HashMap<String, contact> Contacts = new HashMap<>();	

	private contact GetContact(String UID)
	{
		if(Contacts.containsKey(UID))
			return Contacts.get(UID);
		else
			return null;
	}
	public void AddContact(String UID)
	{
			contact newContact = new contact();
			newContact.SetUID(UID);
			if(UID != null)
				Contacts.put(UID, newContact);
	}

	public void RemoveContact(String UID)
	{
		Contacts.remove(UID);
	}
	public void UpdateFirstName(String UID, String firstName)
	{
		GetContact(UID).SetFirstName(firstName);
	}
	public void UpdateLastName(String UID, String lastName)
	{
		GetContact(UID).SetLastName(lastName);
	}
	public void UpdatePhone(String UID, String phone)
	{
		GetContact(UID).SetPhone(phone);
	}
	public void UpdateAddress(String UID, String address)
	{
		GetContact(UID).SetAddress(address);
	}
}
