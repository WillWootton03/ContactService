package contactService;

public class contact {
	
	private String UID = null;
	private String firstName = "default";
	private String lastName = "default";
	private String phone = "default";
	private String address ="default";
	
	public String GetUID() {return UID;}
	public String GetFirstName() {return firstName;}
	public String GetLastName() {return lastName;}
	public String GetPhone() {return phone;}
	public String GetAddress() {return address;}
	
	public void SetUID(String UID)
	{
		if(UID != null && UID.length() <= 10 && UID.length() >= 1)
			this.UID = UID;
		else
			throw new IllegalArgumentException("Incorrect UID Input : " + UID);
	}
	public void SetFirstName(String firstName)
	{
		if(firstName != null && firstName.length() <= 10 && firstName.length() >= 1 && firstName != null)
			this.firstName = firstName;
		else
			throw new IllegalArgumentException("Incorrect firstName Input");
	}
	public void SetLastName(String lastName)
	{
		if(lastName != null && lastName.length() <= 10 && lastName.length() >= 1)
			this.lastName = lastName;
		else
			throw new IllegalArgumentException("Incorrect lastName Input");
	}
	public void SetPhone(String phone)
	{
		if(phone != null && phone.length() <= 10 && phone.length() >= 1)
			this.phone = phone;
		else
			throw new IllegalArgumentException("Incorrect phone Input");
	}
	public void SetAddress(String address)
	{
		if(address != null && address.length() <= 30 && address.length() >= 1)
			this.address = address;
		else
			throw new IllegalArgumentException("Incorrect address Input");
	}

}